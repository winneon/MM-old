package net.minecraftforge.common;

public enum EnumPlantType
{
    Plains,
    Desert,
    Beach,
    Cave,
    Water,
    Nether,
    Crop
}